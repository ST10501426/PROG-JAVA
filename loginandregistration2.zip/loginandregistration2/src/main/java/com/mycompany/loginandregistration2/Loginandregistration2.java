/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.loginandregistration2;

/**
 *
 * @author hificorp
 */
import java.util.Scanner;

public class Loginandregistration2 {

    // Store registered user details
    static String registeredUsername;
    static String registeredPassword;
    static String firstName;
    static String lastName;

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // First name and last name
        System.out.print("Enter first name: ");
        firstName = input.nextLine();

        System.out.print("Enter last name: ");
        lastName = input.nextLine();

        // Username loop
        String username;
        do {
            System.out.print("Enter username: ");
            username = input.nextLine();
            if (!checkUserName(username)) {
                System.out.println("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.");
            }
        } while (!checkUserName(username));

        // Password loop
        String password;
        do {
            System.out.print("Enter password: ");
            password = input.nextLine();
            if (!checkPasswordComplexity(password)) {
                System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number and a special character.");
            }
        } while (!checkPasswordComplexity(password));

        // Cellphone loop
        String cellphonenumber;
        do {
            System.out.print("Enter cellphone number: ");
            cellphonenumber = input.nextLine();
            if (!checkCellPhoneNumber(cellphonenumber)) {
                System.out.println("Cellphone number incorrectly formatted or does not contain international code.");
            }
        } while (!checkCellPhoneNumber(cellphonenumber));

        // Register user
        System.out.println(registerUser(username, password, cellphonenumber));

        // Login loop
        boolean loginSuccess = false;
        do {
            System.out.println("\n====Login====");
            System.out.print("Enter username: ");
            String loginUserName = input.nextLine();
            System.out.print("Enter password: ");
            String loginPassword = input.nextLine();

            loginSuccess = loginUser(loginUserName, loginPassword);
            System.out.println(returnLoginStatus(loginSuccess));
        } while (!loginSuccess); // <-- fixed condition

        input.close();
    }

    public static boolean checkUserName(String username) {
        return username.length() <= 5 && username.contains("_");
    }

    public static boolean checkPasswordComplexity(String password) {
        // Must have at least 8 chars, one uppercase, one digit, one special character
        String passwordPattern = "^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*]).{8,}$";
        return password.matches(passwordPattern);
    }

    public static boolean checkCellPhoneNumber(String cellphonenumber) {
        return cellphonenumber.startsWith("+") && cellphonenumber.length() >= 10;
    }

    public static String registerUser(String username, String password, String cellphonenumber) {
        registeredUsername = username;
        registeredPassword = password;
        return "User registered successfully!";
    }

    public static boolean loginUser(String username, String password) {
        return username.equals(registeredUsername) && password.equals(registeredPassword);
    }

    public static String returnLoginStatus(boolean loginSuccess) {
        if (loginSuccess) {
            return "Welcome " + firstName + ", " + lastName + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}
