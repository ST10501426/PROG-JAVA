/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.loginandregistration;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author hificorp
 */
import org.junit.jupiter.api.Test;

public class LoginandregistrationTest {

    @Test
    public void testCheckUserName_Invalid() {
        String username = "abcdef"; // invalid: too long, no "_"
        boolean expResult = false;
        boolean result = Loginandregistration.checkUserName(username);
        assertEquals(expResult, result);
    }

    @Test
    public void testCheckPasswordComplexity_Valid() {
        String password = "Pass@123"; // valid: meets complexity
        boolean expResult = true;
        boolean result = Loginandregistration.checkPasswordComplexity(password);
        assertEquals(expResult, result);
    }

    @Test
    public void testCheckPasswordComplexity_Invalid() {
        String password = "password"; // invalid: no uppercase, number, special char
        boolean expResult = false;
        boolean result = Loginandregistration.checkPasswordComplexity(password);
        assertEquals(expResult, result);
    }

    @Test
    public void testCheckCellPhoneNumber_Valid() {
        String cellPhoneNumber = "+27123456789"; // valid: has + and digits
        boolean expResult = true;
        boolean result = Loginandregistration.checkCellPhoneNumber(cellPhoneNumber);
        assertEquals(expResult, result);
    }

    @Test
    public void testCheckCellPhoneNumber_Invalid() {
        String cellPhoneNumber = "0123456789"; // invalid: missing +
        boolean expResult = false;
        boolean result = Loginandregistration.checkCellPhoneNumber(cellPhoneNumber);
        assertEquals(expResult, result);
    }
}
