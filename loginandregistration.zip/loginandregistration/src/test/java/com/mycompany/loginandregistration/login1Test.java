/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.loginandregistration;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author hificorp
 */
import org.junit.jupiter.api.Test;

public class login1Test {

    @Test
    public void testLoginUser_Valid() {
        String loginUserName = "user_";
        String registeredUser = "user_";
        String loginPass = "Pass@123";
        String registeredPass = "Pass@123";
        boolean expResult = true;
        boolean result = login1.loginUser(loginUserName, registeredUser, loginPass, registeredPass);
        assertEquals(expResult, result);
    }

    @Test
    public void testLoginUser_Invalid() {
        String loginUserName = "user_";
        String registeredUser = "user_";
        String loginPass = "wrongPass";
        String registeredPass = "Pass@123";
        boolean expResult = false;
        boolean result = login1.loginUser(loginUserName, registeredUser, loginPass, registeredPass);
        assertEquals(expResult, result);
    }

    @Test
    public void testReturnLoginStatus_True() {
        String result = login1.returnLoginStatus(true, "Lebogang", "Khoza");
        assertEquals("Welcome Lebogang Khoza, it is great to see you again.", result);
    }

    @Test
    public void testReturnLoginStatus_False() {
        String result = login1.returnLoginStatus(false, "Lebogang", "Khoza");
        assertEquals("Username or password incorrect, please try again.", result);
    }
}

