/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.loginandregistration;

/**
 *
 * @author hificorp
 */
public class login1 {
   
    
    // === LOGIN METHODS ===
    public static boolean loginUser(String loginUserName, String registeredUser,
                                    String loginPass, String registeredPass) {
        return loginUserName.equals(registeredUser) && loginPass.equals(registeredPass);
    }

    public static String returnLoginStatus(boolean loginSuccess, String firstName, String lastName) {
        if (loginSuccess) {
            return "Welcome " + firstName + " " + lastName + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
    
}
