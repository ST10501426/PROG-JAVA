/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.loginandregistration;

/**
 *
 * @author hificorp
 */
import static com.mycompany.loginandregistration.login1.loginUser;
import static com.mycompany.loginandregistration.login1.returnLoginStatus;
import java.util.Scanner;

public class Loginandregistration {

    // === MAIN METHOD ===
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // --- Registration ---
        System.out.println("=== Registration ===");
        System.out.print("Enter first name: ");
        String firstName = input.nextLine();

        System.out.print("Enter last name: ");
        String lastName = input.nextLine();

        System.out.print("Enter username: ");
        String username = input.nextLine();

        if (checkUserName(username)) {
            System.out.println("Username successfully captured.");
        } else {
            System.out.println("Username is not correctly formatted; "
                    + "please ensure that your username contains an underscore "
                    + "and is no more than five characters in length.");
        }

        System.out.print("Enter password: ");
        String password = input.nextLine();

        if (checkPasswordComplexity(password)) {
            System.out.println("Password successfully captured.");
        } else {
            System.out.println("Password is not correctly formatted; "
                    + "please ensure that the password contains at least eight characters, "
                    + "a capital letter, a number and a special character.");
        }

        System.out.print("Enter cellphone number: ");
        String cellPhoneNumber = input.nextLine();

        if (checkCellPhoneNumber(cellPhoneNumber)) {
            System.out.println("Cellphone number successfully added.");
        } else {
            System.out.println("Cellphone number incorrectly formatted or missing international code.");
        }

        // --- Login ---
        System.out.println("\n=== Login ===");
        System.out.print("Enter username: ");
        String loginUserName = input.nextLine();

        System.out.print("Enter password: ");
        String loginPassword = input.nextLine();

        boolean loginSuccess = loginUser(loginUserName, username, loginPassword, password);
        System.out.println(returnLoginStatus(loginSuccess, firstName, lastName));

        input.close();
    }

    // === VALIDATION METHODS ===
    public static boolean checkUserName(String username) {
        return username.length() <= 5 && username.contains("_");
    }

    public static boolean checkPasswordComplexity(String password) {
        String passwordPattern = "^(?=.*[A-Z])(?=.*[0-9])(?=.*[@#$%^&+=!]).{8,}$";
        return password.matches(passwordPattern);
    }

    public static boolean checkCellPhoneNumber(String cellPhoneNumber) {
        String regexPattern = "^\\+\\d{1,3}\\d{7,12}$"; // +countryCode + number
        return cellPhoneNumber.matches(regexPattern);
    }

   
   
}

